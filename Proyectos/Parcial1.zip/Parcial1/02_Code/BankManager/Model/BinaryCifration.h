/***********************************************************************
 * Module:  BinaryCifration.h
 * Author:  TEVS
 * Modified: martes, 13 de mayo de 2025 20:02:07
 * Purpose: Declaration of the class BinaryCifration
 ***********************************************************************/

#if !defined(__BankManagerProject_BinaryCifration_h)
#define __BankManagerProject_BinaryCifration_h

class BinaryCifration
{
public:
protected:
private:

};

#endif