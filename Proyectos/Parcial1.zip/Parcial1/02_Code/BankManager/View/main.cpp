#include "MenuManager.h"

int main() {
    MenuManager menu;
    menu.loadOptions({"Opción 1", "Opción 2", "Opción 3", "Salir"});
    menu.runMenuLoop();
    return 0;
}
