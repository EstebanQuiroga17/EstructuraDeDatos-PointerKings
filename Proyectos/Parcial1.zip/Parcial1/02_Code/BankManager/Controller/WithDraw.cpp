

#include "WithDraw.h"

WithDraw::WithDraw(float ammount, User user, Date date)
    : BankMovement(ammount, user, date) 
{}

WithDraw::WithDraw()
{
}

WithDraw::~WithDraw()
{
}