#if !defined(__BankManagerProject_Menu_h)
#define __BankManagerProject_Menu_h

#include <vector>
#include <string>
using namespace std;

class Menu
{
public:
protected:
private:
   vector<string> mainMenu;
   vector<string> transaction;
   vector<string> logIn;
};

#endif
