/***********************************************************************
 * Module:  CesarCifration.h
 * Author:  TEVS
 * Modified: martes, 13 de mayo de 2025 20:02:13
 * Purpose: Declaration of the class CesarCifration
 ***********************************************************************/

#if !defined(__BankManagerProject_CesarCifration_h)
#define __BankManagerProject_CesarCifration_h

class CesarCifration
{
public:
protected:
private:

};

#endif